﻿
namespace Mar_va_Peleh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Player1 = new System.Windows.Forms.Label();
            this.BluePlayerTaw = new System.Windows.Forms.PictureBox();
            this.RedPlayerTaw = new System.Windows.Forms.PictureBox();
            this.YellowPlayerTaw = new System.Windows.Forms.PictureBox();
            this.GreenPlayerTaw = new System.Windows.Forms.PictureBox();
            this.Player2 = new System.Windows.Forms.Label();
            this.Player3 = new System.Windows.Forms.Label();
            this.Player4 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblTurn = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.lblFirstHome = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BluePlayerTaw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RedPlayerTaw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YellowPlayerTaw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GreenPlayerTaw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(860, 730);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // Player1
            // 
            this.Player1.BackColor = System.Drawing.Color.Red;
            this.Player1.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.Player1.Location = new System.Drawing.Point(1230, 30);
            this.Player1.Name = "Player1";
            this.Player1.Size = new System.Drawing.Size(160, 50);
            this.Player1.TabIndex = 2;
            this.Player1.Text = "بازیکن اول ";
            this.Player1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.Player1.Visible = false;
            // 
            // BluePlayerTaw
            // 
            this.BluePlayerTaw.BackColor = System.Drawing.SystemColors.Control;
            this.BluePlayerTaw.Image = ((System.Drawing.Image)(resources.GetObject("BluePlayerTaw.Image")));
            this.BluePlayerTaw.InitialImage = ((System.Drawing.Image)(resources.GetObject("BluePlayerTaw.InitialImage")));
            this.BluePlayerTaw.Location = new System.Drawing.Point(0, 657);
            this.BluePlayerTaw.Name = "BluePlayerTaw";
            this.BluePlayerTaw.Size = new System.Drawing.Size(30, 50);
            this.BluePlayerTaw.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BluePlayerTaw.TabIndex = 0;
            this.BluePlayerTaw.TabStop = false;
            this.BluePlayerTaw.Visible = false;
            // 
            // RedPlayerTaw
            // 
            this.RedPlayerTaw.BackColor = System.Drawing.Color.DimGray;
            this.RedPlayerTaw.Image = ((System.Drawing.Image)(resources.GetObject("RedPlayerTaw.Image")));
            this.RedPlayerTaw.InitialImage = ((System.Drawing.Image)(resources.GetObject("RedPlayerTaw.InitialImage")));
            this.RedPlayerTaw.Location = new System.Drawing.Point(0, 657);
            this.RedPlayerTaw.Name = "RedPlayerTaw";
            this.RedPlayerTaw.Size = new System.Drawing.Size(30, 50);
            this.RedPlayerTaw.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.RedPlayerTaw.TabIndex = 0;
            this.RedPlayerTaw.TabStop = false;
            this.RedPlayerTaw.Visible = false;
            // 
            // YellowPlayerTaw
            // 
            this.YellowPlayerTaw.BackColor = System.Drawing.Color.DimGray;
            this.YellowPlayerTaw.Image = ((System.Drawing.Image)(resources.GetObject("YellowPlayerTaw.Image")));
            this.YellowPlayerTaw.Location = new System.Drawing.Point(0, 657);
            this.YellowPlayerTaw.Name = "YellowPlayerTaw";
            this.YellowPlayerTaw.Size = new System.Drawing.Size(30, 50);
            this.YellowPlayerTaw.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.YellowPlayerTaw.TabIndex = 0;
            this.YellowPlayerTaw.TabStop = false;
            this.YellowPlayerTaw.Visible = false;
            // 
            // GreenPlayerTaw
            // 
            this.GreenPlayerTaw.BackColor = System.Drawing.Color.DimGray;
            this.GreenPlayerTaw.Image = ((System.Drawing.Image)(resources.GetObject("GreenPlayerTaw.Image")));
            this.GreenPlayerTaw.Location = new System.Drawing.Point(0, 657);
            this.GreenPlayerTaw.Name = "GreenPlayerTaw";
            this.GreenPlayerTaw.Size = new System.Drawing.Size(30, 50);
            this.GreenPlayerTaw.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GreenPlayerTaw.TabIndex = 0;
            this.GreenPlayerTaw.TabStop = false;
            this.GreenPlayerTaw.Visible = false;
            // 
            // Player2
            // 
            this.Player2.BackColor = System.Drawing.Color.Blue;
            this.Player2.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.Player2.Location = new System.Drawing.Point(1230, 130);
            this.Player2.Name = "Player2";
            this.Player2.Size = new System.Drawing.Size(160, 50);
            this.Player2.TabIndex = 2;
            this.Player2.Text = "بازیکن دوم";
            this.Player2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.Player2.Visible = false;
            // 
            // Player3
            // 
            this.Player3.BackColor = System.Drawing.Color.Yellow;
            this.Player3.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.Player3.Location = new System.Drawing.Point(1230, 230);
            this.Player3.Name = "Player3";
            this.Player3.Size = new System.Drawing.Size(160, 50);
            this.Player3.TabIndex = 2;
            this.Player3.Text = "بازیکن سوم";
            this.Player3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.Player3.Visible = false;
            // 
            // Player4
            // 
            this.Player4.BackColor = System.Drawing.Color.Green;
            this.Player4.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.Player4.Location = new System.Drawing.Point(1220, 325);
            this.Player4.Name = "Player4";
            this.Player4.Size = new System.Drawing.Size(170, 50);
            this.Player4.TabIndex = 2;
            this.Player4.Text = "بازیکن چهارم ";
            this.Player4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.Player4.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.InitialImage")));
            this.pictureBox5.Location = new System.Drawing.Point(1114, 130);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(40, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.InitialImage")));
            this.pictureBox6.Location = new System.Drawing.Point(1114, 30);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(40, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(1114, 230);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(40, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.DimGray;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(1114, 330);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(40, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Silver;
            this.label5.Font = new System.Drawing.Font("B Nazanin", 15F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(990, 498);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(400, 165);
            this.label5.TabIndex = 2;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Visible = false;
            // 
            // lblTurn
            // 
            this.lblTurn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lblTurn.Font = new System.Drawing.Font("B Nazanin", 15F, System.Drawing.FontStyle.Bold);
            this.lblTurn.Location = new System.Drawing.Point(900, 30);
            this.lblTurn.Name = "lblTurn";
            this.lblTurn.Size = new System.Drawing.Size(170, 40);
            this.lblTurn.TabIndex = 2;
            this.lblTurn.Text = "نوبت شماست";
            this.lblTurn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTurn.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(1126, 671);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(153, 59);
            this.button2.TabIndex = 4;
            this.button2.Text = "تغییر نوبت";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(643, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(192, 55);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "بازیکن اول";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.textBox2.Location = new System.Drawing.Point(643, 127);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(192, 55);
            this.textBox2.TabIndex = 6;
            this.textBox2.Text = "بازیکن دوم";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.textBox3.Location = new System.Drawing.Point(643, 225);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(192, 55);
            this.textBox3.TabIndex = 6;
            this.textBox3.Text = "بازیکن سوم";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.textBox4.Location = new System.Drawing.Point(643, 325);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(192, 55);
            this.textBox4.TabIndex = 6;
            this.textBox4.Text = "بازیکن چهارم";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gold;
            this.button1.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button1.Location = new System.Drawing.Point(1126, 436);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 59);
            this.button1.TabIndex = 1;
            this.button1.Text = "تاس بنداز";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(442, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 50);
            this.label2.TabIndex = 2;
            this.label2.Text = "بازیکن اول ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Blue;
            this.label3.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(442, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(160, 50);
            this.label3.TabIndex = 2;
            this.label3.Text = "بازیکن دوم";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Yellow;
            this.label4.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(442, 230);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 50);
            this.label4.TabIndex = 2;
            this.label4.Text = "بازیکن سوم";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Green;
            this.label6.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(442, 325);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(165, 50);
            this.label6.TabIndex = 2;
            this.label6.Text = "بازیکن چهارم ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Font = new System.Drawing.Font("B Nazanin", 15F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(851, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(219, 322);
            this.label7.TabIndex = 2;
            this.label7.Text = "طبق رنگ و ترتیب اسم افراد را میتوانید وارد کنید یا به صورت پیش فرض انتخاب کنید";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Olive;
            this.button3.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button3.Location = new System.Drawing.Point(660, 409);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(175, 59);
            this.button3.TabIndex = 1;
            this.button3.Text = "ورود به بازی";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button4.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button4.Location = new System.Drawing.Point(286, 809);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(175, 59);
            this.button4.TabIndex = 1000;
            this.button4.Text = "خروج ";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button5.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button5.Location = new System.Drawing.Point(660, 491);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(175, 59);
            this.button5.TabIndex = 1;
            this.button5.Text = "خروج ";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button4_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button6.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button6.Location = new System.Drawing.Point(211, 32);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(175, 50);
            this.button6.TabIndex = 1;
            this.button6.Text = "حذف";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button7.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button7.Location = new System.Drawing.Point(12, 30);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(175, 50);
            this.button7.TabIndex = 1;
            this.button7.Text = "برگرداندند";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button8.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button8.Location = new System.Drawing.Point(211, 128);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(175, 50);
            this.button8.TabIndex = 1;
            this.button8.Text = "حذف";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button9.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button9.Location = new System.Drawing.Point(12, 126);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(175, 50);
            this.button9.TabIndex = 1;
            this.button9.Text = "برگرداندند";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button10.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button10.Location = new System.Drawing.Point(211, 230);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(175, 50);
            this.button10.TabIndex = 1;
            this.button10.Text = "حذف";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button11.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button11.Location = new System.Drawing.Point(12, 228);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(175, 50);
            this.button11.TabIndex = 1;
            this.button11.Text = "برگرداندند";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button12.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button12.Location = new System.Drawing.Point(211, 323);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(175, 50);
            this.button12.TabIndex = 1;
            this.button12.Text = "حذف";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button13.Font = new System.Drawing.Font("B Nazanin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button13.Location = new System.Drawing.Point(12, 321);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(175, 50);
            this.button13.TabIndex = 1;
            this.button13.Text = "برگرداندند";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // lblFirstHome
            // 
            this.lblFirstHome.BackColor = System.Drawing.Color.White;
            this.lblFirstHome.Location = new System.Drawing.Point(0, 657);
            this.lblFirstHome.Name = "lblFirstHome";
            this.lblFirstHome.Size = new System.Drawing.Size(30, 50);
            this.lblFirstHome.TabIndex = 1001;
            this.lblFirstHome.Text = "First Home";
            this.lblFirstHome.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GreenYellow;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.lblFirstHome);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lblTurn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Player4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Player3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Player2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Player1);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.GreenPlayerTaw);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.YellowPlayerTaw);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.RedPlayerTaw);
            this.Controls.Add(this.BluePlayerTaw);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BluePlayerTaw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RedPlayerTaw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YellowPlayerTaw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GreenPlayerTaw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Player1;
        private System.Windows.Forms.PictureBox BluePlayerTaw;
        private System.Windows.Forms.PictureBox RedPlayerTaw;
        private System.Windows.Forms.PictureBox YellowPlayerTaw;
        private System.Windows.Forms.PictureBox GreenPlayerTaw;
        private System.Windows.Forms.Label Player2;
        private System.Windows.Forms.Label Player3;
        private System.Windows.Forms.Label Player4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblTurn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label lblFirstHome;
    }
}

