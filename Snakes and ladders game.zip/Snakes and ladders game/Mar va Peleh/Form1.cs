﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mar_va_Peleh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Dice and Move
        private void button1_Click(object sender, EventArgs e)
        {

            Random random = new Random();
            int digit = random.Next(1, 7);
            label5.Text = digit.ToString() + "خانه به جلو برو";

            button2.Enabled = true;
            button1.Enabled = false;

            Point point_turn = new Point();
            point_turn.Y = lblTurn.Location.Y;

            //حرکت مهره های بازی

            //Red Taw
            if (TawIf(RedPlayerTaw))
            {
                if (ChekTurn(Player1))
                {
                    Move(digit, RedPlayerTaw, Player1);
                    IfOneHome(RedPlayerTaw, BluePlayerTaw, Player1, Player2);
                    IfOneHome(RedPlayerTaw, GreenPlayerTaw, Player1, Player4);
                    IfOneHome(RedPlayerTaw, YellowPlayerTaw, Player1, Player3);
                }
            }

            //Blue Taw
            if (TawIf(BluePlayerTaw))
            {
                if (ChekTurn(Player2))
                {
                    Move(digit, BluePlayerTaw, Player2);
                    IfOneHome(BluePlayerTaw, RedPlayerTaw, Player2, Player1);
                    IfOneHome(BluePlayerTaw, GreenPlayerTaw, Player2, Player4);
                    IfOneHome(BluePlayerTaw, YellowPlayerTaw, Player2, Player3);
                }
            }

            //Yellow Taw
            if (TawIf(YellowPlayerTaw))
            {
                if (ChekTurn(Player3))
                {
                    Move(digit, YellowPlayerTaw, Player3);
                    IfOneHome(YellowPlayerTaw, BluePlayerTaw, Player3, Player2);
                    IfOneHome(YellowPlayerTaw, GreenPlayerTaw, Player3, Player4);
                    IfOneHome(YellowPlayerTaw, RedPlayerTaw, Player3, Player1);
                }
            }

            //Green Taw
            if (TawIf(GreenPlayerTaw))
            {
                if (ChekTurn(Player4))
                {
                    Move(digit, GreenPlayerTaw, Player4);
                    IfOneHome(GreenPlayerTaw, BluePlayerTaw, Player4, Player2);
                    IfOneHome(GreenPlayerTaw, RedPlayerTaw, Player4, Player1);
                    IfOneHome(GreenPlayerTaw, YellowPlayerTaw, Player4, Player3);
                }
            }
        }
        private bool ChekTurn(Label player)
        {
            if (player.Location.Y == lblTurn.Location.Y)
                return true;
            else
                return false;
        }
        private bool TawIf(PictureBox taw_color)
        {
            if (taw_color.Visible == true)
                return true;
            else
                return false;
        }
        private void Move(int tas, PictureBox taw, Label player_num)
        {

            Point point_taw = new Point();
            point_taw.X = taw.Location.X;
            point_taw.Y = taw.Location.Y;

            for (int j = 1; j <= tas; j++)
            {
                if (point_taw.Y % 2 == 1)
                {
                    if ((point_taw.X < 65) && (point_taw.X >= 0))
                    {
                        point_taw.Y -= 59;
                        point_taw.X = taw.Location.X;
                        taw.Location = point_taw;
                    }
                    else
                    {
                        point_taw.Y = taw.Location.Y;
                        point_taw.X -= 65;
                        taw.Location = point_taw;
                    }
                }
                else
                {
                    if ((point_taw.X <= 645) && (point_taw.X > 581))
                    {
                        point_taw.Y -= 59;
                        point_taw.X = taw.Location.X;
                        taw.Location = point_taw;
                    }
                    else
                    {
                        point_taw.Y = taw.Location.Y;
                        point_taw.X += 65;
                        taw.Location = point_taw;
                    }
                }

            }
            //مار و نردبان
            //Ladder
            if ((taw.Location.X == 585) && (taw.Location.Y == 121))
            {
                point_taw.X = 520;
                point_taw.Y = 3;
                taw.Location = point_taw;
                LadderUp();
            }
            if ((taw.Location.X == 65) && (taw.Location.Y == 534))
            {
                point_taw.X = 130;
                point_taw.Y = 416;
                taw.Location = point_taw;
                LadderUp();
            }
            if ((taw.Location.X == 325) && (taw.Location.Y == 534))
            {
                point_taw.X = 260;
                point_taw.Y = 298;
                taw.Location = point_taw;
                LadderUp();
            }
            if ((taw.Location.X == 0) && (taw.Location.Y == 475))
            {
                point_taw.X = 65;
                point_taw.Y = 239;
                taw.Location = point_taw;
                LadderUp();
            }
            if ((taw.Location.X == 520) && (taw.Location.Y == 239))
            {
                point_taw.X = 520;
                point_taw.Y = 121;
                taw.Location = point_taw;
                LadderUp();
            }
            if ((taw.Location.X == 195) && (taw.Location.Y == 239))
            {
                point_taw.X = 260;
                point_taw.Y = 3;
                taw.Location = point_taw;
                LadderUp();
            }
            //Snake
            if ((taw.Location.X == 585) && (taw.Location.Y == 298))
            {
                point_taw.X = 260;
                point_taw.Y = 534;
                taw.Location = point_taw;
                SnakeAttak();
            }
            if ((taw.Location.X == 260) && (taw.Location.Y == 239))
            {
                point_taw.X = 455;
                point_taw.Y = 534;
                taw.Location = point_taw;
                SnakeAttak();
            }
            if ((taw.Location.X == 455) && (taw.Location.Y == 121))
            {
                point_taw.X = 325;
                point_taw.Y = 475;
                taw.Location = point_taw;
                SnakeAttak();
            }
            if ((taw.Location.X == 130) && (taw.Location.Y == 298))
            {
                point_taw.X = 195;
                point_taw.Y = 475;
                taw.Location = point_taw;
                SnakeAttak();
            }
            if ((taw.Location.X == 390) && (taw.Location.Y == 62))
            {
                point_taw.X = 520;
                point_taw.Y = 298;
                taw.Location = point_taw;
                SnakeAttak();
            }
            if ((taw.Location.X == 195) && (taw.Location.Y == 62))
            {
                point_taw.X = 130;
                point_taw.Y = 239;
                taw.Location = point_taw;
                SnakeAttak();
            }
            if ((taw.Location.X == 130) && (taw.Location.Y == 3))
            {
                point_taw.X = 0;
                point_taw.Y = 357;
                taw.Location = point_taw;
                SnakeAttak();
            }

            //برنده و پایان بازی
            if ((taw.Location.X == 0) && (taw.Location.Y == 3))
                Congratulates(taw, player_num);
            else if (taw.Location.Y < 0)
                Congratulates(taw, player_num);

            //تاس عدد 6 بیاید
            if (tas == 6)
            {
                label5.Text = label5.Text + '\n' + "یکبار دیگه تاس بنداز";
                ChangeTurn();
            }
            taw.Location = point_taw;
        }
        private void LadderUp() => label5.Text = label5.Text + '\n' + "از نردبان  بالا برو";
        private void SnakeAttak() => label5.Text = label5.Text + '\n' + "ای وای مار نیشت زد";
        //Tabrik
        private void Congratulates(PictureBox taw, Label player_name)
        {
            taw.Location = pictureBox1.Location;
            MessageBox.Show("  تبریک به  " + player_name.Text + " شما برنده شدید ");
            button1.Enabled = false;
            Application.Restart();
        }

        //Attack another Player
        private void IfOneHome(PictureBox newTaw, PictureBox lastTaw,
            Label newPlayer, Label lastPlayer)
        {
            if (newTaw.Location == lastTaw.Location)
            {
                lastTaw.Top = lblFirstHome.Top;
                lastTaw.Left = lblFirstHome.Left;
                label5.Text += '\n' + newPlayer.Text + " , " + lastPlayer.Text + " را زد " +
                    "و به خانه اول بازی برگرداند";
            }
        }

        //Change Player Turn
        private void button2_Click(object sender, EventArgs e)
        {
            Point poinTurn = new Point();
            poinTurn.X = lblTurn.Location.X;
            if (ForVisibleState(true, true, true, true))
            {
                DefaultTurnLocation(poinTurn, Player1);

                if (lblTurn.Location.Y == Player1.Location.Y)
                    ChangeTurnLocation(poinTurn, Player2);
                else if (lblTurn.Location.Y == Player2.Location.Y)
                    ChangeTurnLocation(poinTurn, Player3);
                else if (lblTurn.Location.Y == Player3.Location.Y)
                    ChangeTurnLocation(poinTurn, Player4);
                else if (lblTurn.Location.Y == Player4.Location.Y)
                    ChangeTurnLocation(poinTurn, Player1);

                ChangeTurn();
            }
            else if (ForVisibleState(false, true, true, true))
            {
                DefaultTurnLocation(poinTurn, Player2);

                if (lblTurn.Location.Y == Player2.Location.Y)
                    ChangeTurnLocation(poinTurn, Player3);
                else if (lblTurn.Location.Y == Player3.Location.Y)
                    ChangeTurnLocation(poinTurn, Player4);
                else if (lblTurn.Location.Y == Player4.Location.Y)
                    ChangeTurnLocation(poinTurn, Player2);

                ChangeTurn();
            }
            else if (ForVisibleState(true, false, true, true))
            {
                DefaultTurnLocation(poinTurn, Player1);

                if (lblTurn.Location.Y == Player1.Location.Y)
                    ChangeTurnLocation(poinTurn, Player3);
                else if (lblTurn.Location.Y == Player3.Location.Y)
                    ChangeTurnLocation(poinTurn, Player4);
                else if (lblTurn.Location.Y == Player4.Location.Y)
                    ChangeTurnLocation(poinTurn, Player1);

                ChangeTurn();
            }
            else if (ForVisibleState(true, true, false, true))
            {
                DefaultTurnLocation(poinTurn, Player1);

                if (lblTurn.Location.Y == Player1.Location.Y)
                    ChangeTurnLocation(poinTurn, Player2);
                else if (lblTurn.Location.Y == Player2.Location.Y)
                    ChangeTurnLocation(poinTurn, Player4);
                else if (lblTurn.Location.Y == Player4.Location.Y)
                    ChangeTurnLocation(poinTurn, Player1);

                ChangeTurn();
            }
            else if (ForVisibleState(true, true, true, false))
            {
                DefaultTurnLocation(poinTurn, Player1);

                if (lblTurn.Location.Y == Player1.Location.Y)
                    ChangeTurnLocation(poinTurn, Player2);
                else if (lblTurn.Location.Y == Player2.Location.Y)
                    ChangeTurnLocation(poinTurn, Player3);
                else if (lblTurn.Location.Y == Player3.Location.Y)
                    ChangeTurnLocation(poinTurn, Player1);

                ChangeTurn();
            }
            else if (ForVisibleState(false, false, true, true))
            {
                DefaultTurnLocation(poinTurn, Player3);

                if (lblTurn.Location.Y == Player3.Location.Y)
                    ChangeTurnLocation(poinTurn, Player4);
                else if (lblTurn.Location.Y == Player4.Location.Y)
                    ChangeTurnLocation(poinTurn, Player3);

                ChangeTurn();
            }
            else if (ForVisibleState(false, true, false, true))
            {
                DefaultTurnLocation(poinTurn, Player2);

                if (lblTurn.Location.Y == Player2.Location.Y)
                    ChangeTurnLocation(poinTurn, Player4);
                else if (lblTurn.Location.Y == Player4.Location.Y)
                    ChangeTurnLocation(poinTurn, Player2);

                ChangeTurn();
            }
            else if (ForVisibleState(false, true, false, true))
            {
                DefaultTurnLocation(poinTurn, Player2);

                if (lblTurn.Location.Y == Player2.Location.Y)
                    ChangeTurnLocation(poinTurn, Player3);
                else if (lblTurn.Location.Y == Player3.Location.Y)
                    ChangeTurnLocation(poinTurn, Player2);

                ChangeTurn();
            }
            else if (ForVisibleState(true, false, false, true))
            {
                DefaultTurnLocation(poinTurn, Player1);

                if (lblTurn.Location.Y == Player1.Location.Y)
                    ChangeTurnLocation(poinTurn, Player4);
                else if (lblTurn.Location.Y == Player4.Location.Y)
                    ChangeTurnLocation(poinTurn, Player1);

                ChangeTurn();
            }
            else if (ForVisibleState(true, false, true, false))
            {
                DefaultTurnLocation(poinTurn, Player1);

                if (lblTurn.Location.Y == Player1.Location.Y)
                    ChangeTurnLocation(poinTurn, Player3);
                else if (lblTurn.Location.Y == Player3.Location.Y)
                    ChangeTurnLocation(poinTurn, Player1);

                ChangeTurn();
            }
            else if (ForVisibleState(true, true, false, false))
            {
                DefaultTurnLocation(poinTurn, Player1);

                if (lblTurn.Location.Y == Player1.Location.Y)
                    ChangeTurnLocation(poinTurn, Player2);
                else if (lblTurn.Location.Y == Player2.Location.Y)
                    ChangeTurnLocation(poinTurn, Player1);

                ChangeTurn();
            }
        }
        private void ChangeTurnLocation(Point poinTurn, Label player)
        {
            poinTurn.Y = player.Location.Y;
            lblTurn.Location = poinTurn;
        }
        private void ChangeTurn()
        {
            button1.Enabled = true;
            button2.Enabled = false;
        }
        private void DefaultTurnLocation(Point pointTurn, Label player) => pointTurn.Y = player.Location.Y;

        //In to the Game
        private void button3_Click(object sender, EventArgs e)
        {
            Player1.Text = textBox1.Text;
            Player2.Text = textBox2.Text;
            Player3.Text = textBox3.Text;
            Player4.Text = textBox4.Text;

            foreach (Control item in this.Controls)
            {
                if (item.Visible == true)
                    item.Visible = false;
                else
                    item.Visible = true;
            }
            lblFirstHome.Visible = false;

            IfTaw(textBox1, RedPlayerTaw, pictureBox6, Player1);
            IfTaw(textBox2, BluePlayerTaw, pictureBox5, Player2);
            IfTaw(textBox3, YellowPlayerTaw, pictureBox7, Player3);
            IfTaw(textBox4, GreenPlayerTaw, pictureBox8, Player4);

            FirstTurn();
        }
        private void FirstTurn()
        {
            Point point_help = new Point();
            if (ForVisibleState(true, true, true, true))
                FirstTurnLocation(point_help, Player1);

            else if (ForVisibleState(false, true, true, true))
                FirstTurnLocation(point_help, Player2);

            else if (ForVisibleState(true, false, true, true))
                FirstTurnLocation(point_help, Player1);

            else if (ForVisibleState(true, true, false, true))
                FirstTurnLocation(point_help, Player1);

            else if (ForVisibleState(true, true, true, false))
                FirstTurnLocation(point_help, Player1);

            else if (ForVisibleState(false, false, true, true))
                FirstTurnLocation(point_help, Player3);

            else if (ForVisibleState(false, true, false, true))
                FirstTurnLocation(point_help, Player2);

            else if (ForVisibleState(false, true, false, true))
                FirstTurnLocation(point_help, Player2);

            else if (ForVisibleState(true, false, false, true))
                FirstTurnLocation(point_help, Player1);

            else if (ForVisibleState(true, false, true, false))
                FirstTurnLocation(point_help, Player1);

            else if (ForVisibleState(true, true, false, false))
                FirstTurnLocation(point_help, Player1);
        }
        private void FirstTurnLocation(Point point, Label player)
        {
            point.X = lblTurn.Location.X;
            point.Y = player.Location.Y;
            lblTurn.Location = point;
        }
        private bool ForVisible(Label player, bool chek)
        {
            if (player.Visible == chek)
                return true;
            else
                return false;
        }
        private bool ForVisibleState(bool b1, bool b2, bool b3, bool b4)
        {
            if (ForVisible(Player1, b1) && ForVisible(Player2, b2)
                && ForVisible(Player3, b3) && ForVisible(Player4, b4))
                return true;
            else
                return false;
        }

        private void IfTaw(TextBox textBox, PictureBox color_taw
        , PictureBox pictureBox, Label player)
        {
            if (ForAll(textBox, false))
                player.Visible = pictureBox.Visible = color_taw.Visible = false;
            else
                player.Visible = pictureBox.Visible = color_taw.Visible = true;
        }

        //Out from the Game
        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Restore Button
        private void button7_Click(object sender, EventArgs e) => IfInput(textBox1);
        private void button9_Click(object sender, EventArgs e) => IfInput(textBox2);
        private void button11_Click(object sender, EventArgs e) => IfInput(textBox3);
        private void button13_Click(object sender, EventArgs e) => IfInput(textBox4);
        private void IfInput(TextBox textBox)
        {
            textBox.Enabled = true;
            if (IfPlayState(true, true, true, true))
                CanPlay();
            else if (IfPlayState(false, true, true, true))
                CanPlay();
            else if (IfPlayState(true, false, true, true))
                CanPlay();
            else if (IfPlayState(true, true, false, true))
                CanPlay();
            else if (IfPlayState(true, true, true, false))
                CanPlay();
            else if (IfPlayState(false, false, true, true))
                CanPlay();
            else if (IfPlayState(false, true, false, true))
                CanPlay();
            else if (IfPlayState(false, true, true, false))
                CanPlay();
            else if (IfPlayState(false, true, true, false))
                CanPlay();
            else if (IfPlayState(true, false, true, false))
                CanPlay();
            else if (IfPlayState(true, true, false, false))
                CanPlay();
            else
                button3.Enabled = false;
        }
        private void CanPlay() => button3.Enabled = true;

        //Delete Button 
        private void button6_Click(object sender, EventArgs e) => IfPlay(textBox1);
        private void button8_Click(object sender, EventArgs e) => IfPlay(textBox2);
        private void button10_Click(object sender, EventArgs e) => IfPlay(textBox3);
        private void button12_Click(object sender, EventArgs e) => IfPlay(textBox4);
        private void IfPlay(TextBox textBox)
        {
            textBox.Enabled = false;
            if (IfPlayState(false, false, false, false))
                ShowCannotPlay();
            else if (IfPlayState(true, false, false, false))
                ShowCannotPlay();
            else if (IfPlayState(false, true, false, false))
                ShowCannotPlay();
            else if (IfPlayState(false, false, true, false))
                ShowCannotPlay();
            else if (IfPlayState(false, false, false, true))
                ShowCannotPlay();
            else
                button3.Enabled = true;
        }
        private bool IfPlayState(bool b1, bool b2, bool b3, bool b4)
        {
            if (ForAll(textBox1, b1) && ForAll(textBox2, b2)
                && ForAll(textBox3, b3) && ForAll(textBox4, b4))
                return true;
            else
                return false;

        }
        private void ShowCannotPlay()
        {
            button3.Enabled = false;
            label7.Text = label7.Text + '\n' +
                "حداقل باید دو بازیکن وجود داشته باشد";
        }

        //For If's which one for Enable
        private bool ForAll(TextBox text, bool chek)
        {
            if (text.Enabled == chek)
                return true;
            else
                return false;
        }
    }
}

